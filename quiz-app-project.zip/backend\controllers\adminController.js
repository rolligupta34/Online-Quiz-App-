const User = require('../models/User');
const Quiz = require('../models/Quiz');
const Result = require('../models/Result');
const jwt = require('jsonwebtoken');

const generateToken = (id) => {
    return jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: '30d' });
};

// --- AUTH ---
// Moved to authController.js

// --- DASHBOARD/METRICS ---
const getMetrics = async (req, res) => {
    try {
        const quizCount = await Quiz.countDocuments();
        const studentCount = await User.countDocuments({ role: 'student' });
        const attemptCount = await Result.countDocuments();
        res.json({ quizCount, studentCount, attemptCount });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// --- QUIZZES ---
const createQuiz = async (req, res) => {
    const { title, description, category, timeLimit } = req.body;
    try {
        const quiz = await Quiz.create({ title, description, category, timeLimit, creator: req.user._id, questions: [] });
        res.status(201).json(quiz);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
};

const getAllQuizzes = async (req, res) => {
    try {
        const quizzes = await Quiz.find({}).populate('creator', 'name');
        res.json(quizzes);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

const updateQuiz = async (req, res) => {
    const { title, description, category, timeLimit, questions, isPublished } = req.body;
    try {
        const quiz = await Quiz.findById(req.params.id);
        if (quiz) {
            if(title !== undefined) quiz.title = title;
            if(description !== undefined) quiz.description = description;
            if(category !== undefined) quiz.category = category;
            if(timeLimit !== undefined) quiz.timeLimit = timeLimit;
            if(questions !== undefined) quiz.questions = questions;
            if(isPublished !== undefined) quiz.isPublished = isPublished;
            const updatedQuiz = await quiz.save();
            res.json(updatedQuiz);
        } else res.status(404).json({ message: 'Quiz not found' });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

const deleteQuiz = async (req, res) => {
    try {
        const quiz = await Quiz.findById(req.params.id);
        if (quiz) {
            await quiz.deleteOne();
            await Result.deleteMany({ quiz: req.params.id }); // cascade delete
            res.json({ message: 'Quiz removed' });
        } else res.status(404).json({ message: 'Quiz not found' });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// --- USERS ---
const getAllStudents = async (req, res) => {
    try {
        const students = await User.find({ role: 'student' }).select('-password');
        res.json(students);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

const deleteStudent = async (req, res) => {
    try {
        const student = await User.findById(req.params.id);
        if (student) {
            await student.deleteOne();
            await Result.deleteMany({ student: req.params.id });
            res.json({ message: 'Student removed' });
        } else {
            res.status(404).json({ message: 'Student not found' });
        }
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// --- ANALYTICS ---
const getQuizAnalytics = async (req, res) => {
    try {
        const results = await Result.find({ quiz: req.params.id }).populate('student', 'name email');
        const quiz = await Quiz.findById(req.params.id);
        if (!quiz) return res.status(404).json({ message: 'Quiz not found' });

        const totalAttempts = results.length;
        const averageScore = totalAttempts > 0 ? results.reduce((acc, curr) => acc + (curr.score / curr.totalQuestions), 0) / totalAttempts : 0;

        res.json({ totalAttempts, averageScore: averageScore * 100, results });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

module.exports = {
    getMetrics,
    createQuiz, getAllQuizzes, updateQuiz, deleteQuiz,
    getAllStudents, deleteStudent, getQuizAnalytics
};
