import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import api from '../services/api';
import toast from 'react-hot-toast';
import AdminNavbar from './AdminNavbar';
import { motion } from 'framer-motion';
import { FiArrowLeft, FiAward, FiUsers } from 'react-icons/fi';

const QuizAnalytics = () => {
    const { quizId } = useParams();
    const [analytics, setAnalytics] = useState({ totalAttempts: 0, averageScore: 0, results: [] });

    useEffect(() => {
        const fetchAnalytics = async () => {
            try {
                const { data } = await api.get(`/admin/quizzes/${quizId}/analytics`);
                setAnalytics(data);
            } catch (error) {
                toast.error("Failed to load analytics");
            }
        };
        fetchAnalytics();
    }, [quizId]);

    return (
        <div className="min-h-screen bg-slate-50 font-sans">
            <AdminNavbar />
            <main className="max-w-7xl mx-auto px-4 py-12">
                <div className="mb-8 flex items-center gap-4">
                    <Link to="/admin/manage-quizzes" className="text-slate-500 hover:text-slate-900 bg-slate-200 p-2 rounded-full transition-colors"><FiArrowLeft /></Link>
                    <h2 className="text-3xl font-black text-slate-900">Quiz Analytics</h2>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
                    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 flex items-center gap-6">
                        <div className="p-4 bg-indigo-100 text-indigo-600 rounded-2xl"><FiUsers className="text-3xl" /></div>
                        <div>
                            <p className="text-sm font-bold text-slate-500 uppercase tracking-wider">Total Attempts</p>
                            <h3 className="text-4xl font-black text-slate-900">{analytics.totalAttempts}</h3>
                        </div>
                    </motion.div>

                    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 flex items-center gap-6">
                        <div className="p-4 bg-emerald-100 text-emerald-600 rounded-2xl"><FiAward className="text-3xl" /></div>
                        <div>
                            <p className="text-sm font-bold text-slate-500 uppercase tracking-wider">Average Score</p>
                            <h3 className="text-4xl font-black text-slate-900">{analytics.averageScore.toFixed(1)}%</h3>
                        </div>
                    </motion.div>
                </div>

                <h3 className="text-2xl font-bold text-slate-800 mb-6">Attempt History</h3>
                <div className="bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden">
                    <table className="w-full text-left border-collapse">
                        <thead>
                            <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase tracking-wider text-xs font-bold">
                                <th className="p-4">Student</th>
                                <th className="p-4">Email</th>
                                <th className="p-4">Score</th>
                                <th className="p-4">Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            {analytics.results.map((result, idx) => (
                                <motion.tr initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: idx * 0.05 }} key={result._id} className="border-b border-slate-100 hover:bg-slate-50">
                                    <td className="p-4 font-bold text-slate-800">{result.student?.name}</td>
                                    <td className="p-4 text-slate-600">{result.student?.email}</td>
                                    <td className="p-4 font-bold text-indigo-600">{result.score} / {result.totalQuestions}</td>
                                    <td className="p-4 text-slate-500 text-sm">{new Date(result.createdAt).toLocaleString()}</td>
                                </motion.tr>
                            ))}
                        </tbody>
                    </table>
                    {analytics.results.length === 0 && (
                        <div className="p-8 text-center text-slate-500">No attempts yet.</div>
                    )}
                </div>
            </main>
        </div>
    );
};

export default QuizAnalytics;
