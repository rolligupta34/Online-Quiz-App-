import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import api from '../services/api';
import toast from 'react-hot-toast';
import AdminNavbar from './AdminNavbar';
import { motion } from 'framer-motion';
import { FiEdit2, FiTrash2, FiBarChart2, FiCheckCircle, FiXCircle } from 'react-icons/fi';

const ManageQuizzes = () => {
    const [quizzes, setQuizzes] = useState([]);

    const fetchQuizzes = async () => {
        try {
            const { data } = await api.get('/admin/quizzes');
            setQuizzes(data);
        } catch (error) {
            toast.error("Failed to load quizzes");
        }
    };

    useEffect(() => {
        fetchQuizzes();
    }, []);

    const togglePublish = async (id, currentStatus) => {
        try {
            await api.put(`/admin/quizzes/${id}`, { isPublished: !currentStatus });
            toast.success(`Quiz ${!currentStatus ? 'published' : 'unpublished'}`);
            fetchQuizzes();
        } catch (error) {
            toast.error("Failed to update status");
        }
    };

    const deleteQuiz = async (id) => {
        if (!window.confirm("Are you sure? This deletes the quiz and all related results.")) return;
        try {
            await api.delete(`/admin/quizzes/${id}`);
            toast.success("Quiz deleted");
            fetchQuizzes();
        } catch (error) {
            toast.error("Failed to delete quiz");
        }
    };

    return (
        <div className="min-h-screen bg-slate-50 font-sans">
            <AdminNavbar />
            <main className="max-w-7xl mx-auto px-4 py-12">
                <div className="flex justify-between items-center mb-8">
                    <h2 className="text-3xl font-black text-slate-900">Manage Quizzes</h2>
                    <Link to="/admin/add-quiz" className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-6 rounded-xl transition-colors">
                        + New Quiz
                    </Link>
                </div>

                <div className="bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden">
                    <table className="w-full text-left border-collapse">
                        <thead>
                            <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase tracking-wider text-xs font-bold">
                                <th className="p-4">Title</th>
                                <th className="p-4">Category</th>
                                <th className="p-4">Questions</th>
                                <th className="p-4">Status</th>
                                <th className="p-4 text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {quizzes.map((quiz, idx) => (
                                <motion.tr initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: idx * 0.05 }} key={quiz._id} className="border-b border-slate-100 hover:bg-slate-50">
                                    <td className="p-4 font-bold text-slate-800">{quiz.title}</td>
                                    <td className="p-4 text-slate-600">
                                        <span className="bg-indigo-100 text-indigo-700 px-3 py-1 rounded-full text-xs font-bold">{quiz.category}</span>
                                    </td>
                                    <td className="p-4 text-slate-600 font-medium">{quiz.questions.length}</td>
                                    <td className="p-4">
                                        <button onClick={() => togglePublish(quiz._id, quiz.isPublished)} 
                                            className={`flex items-center gap-1 text-xs font-bold px-3 py-1 rounded-full ${quiz.isPublished ? 'bg-emerald-100 text-emerald-700 hover:bg-emerald-200' : 'bg-slate-100 text-slate-500 hover:bg-slate-200'}`}>
                                            {quiz.isPublished ? <><FiCheckCircle /> Published</> : <><FiXCircle /> Draft</>}
                                        </button>
                                    </td>
                                    <td className="p-4 flex justify-end gap-3">
                                        <Link to={`/admin/analytics/${quiz._id}`} className="text-blue-500 hover:bg-blue-50 p-2 rounded-lg" title="Analytics"><FiBarChart2 /></Link>
                                        <Link to={`/admin/add-question/${quiz._id}`} className="text-indigo-500 hover:bg-indigo-50 p-2 rounded-lg" title="Edit Questions"><FiEdit2 /></Link>
                                        <button onClick={() => deleteQuiz(quiz._id)} className="text-red-500 hover:bg-red-50 p-2 rounded-lg" title="Delete"><FiTrash2 /></button>
                                    </td>
                                </motion.tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </main>
        </div>
    );
};

export default ManageQuizzes;
