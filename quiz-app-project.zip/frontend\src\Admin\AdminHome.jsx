import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { FiUsers, FiBookOpen, FiActivity } from 'react-icons/fi';
import api from '../services/api';
import AdminNavbar from './AdminNavbar';

const AdminHome = () => {
    const [metrics, setMetrics] = useState({ quizCount: 0, studentCount: 0, attemptCount: 0 });

    useEffect(() => {
        const fetchMetrics = async () => {
            try {
                const { data } = await api.get('/admin/metrics');
                setMetrics(data);
            } catch (error) {
                console.error("Failed to load metrics");
            }
        };
        fetchMetrics();
    }, []);

    const containerVariants = {
        hidden: { opacity: 0 },
        visible: { opacity: 1, transition: { staggerChildren: 0.1 } }
    };

    const itemVariants = {
        hidden: { y: 20, opacity: 0 },
        visible: { y: 0, opacity: 1 }
    };

    return (
        <div className="min-h-screen bg-slate-50 font-sans selection:bg-pink-500/30">
            <AdminNavbar />
            <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
                <h1 className="text-4xl font-black text-slate-900 mb-8 tracking-tight">Admin Dashboard</h1>
                
                <motion.div 
                    variants={containerVariants}
                    initial="hidden"
                    animate="visible"
                    className="grid grid-cols-1 md:grid-cols-3 gap-6"
                >
                    <motion.div variants={itemVariants} className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 flex items-center gap-6 hover:shadow-md transition-shadow">
                        <div className="p-4 bg-indigo-100 text-indigo-600 rounded-2xl">
                            <FiBookOpen className="text-3xl" />
                        </div>
                        <div>
                            <p className="text-sm font-bold text-slate-500 uppercase tracking-wider">Total Quizzes</p>
                            <h3 className="text-3xl font-black text-slate-900">{metrics.quizCount}</h3>
                        </div>
                    </motion.div>

                    <motion.div variants={itemVariants} className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 flex items-center gap-6 hover:shadow-md transition-shadow">
                        <div className="p-4 bg-pink-100 text-pink-600 rounded-2xl">
                            <FiUsers className="text-3xl" />
                        </div>
                        <div>
                            <p className="text-sm font-bold text-slate-500 uppercase tracking-wider">Registered Students</p>
                            <h3 className="text-3xl font-black text-slate-900">{metrics.studentCount}</h3>
                        </div>
                    </motion.div>

                    <motion.div variants={itemVariants} className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 flex items-center gap-6 hover:shadow-md transition-shadow">
                        <div className="p-4 bg-emerald-100 text-emerald-600 rounded-2xl">
                            <FiActivity className="text-3xl" />
                        </div>
                        <div>
                            <p className="text-sm font-bold text-slate-500 uppercase tracking-wider">Total Attempts</p>
                            <h3 className="text-3xl font-black text-slate-900">{metrics.attemptCount}</h3>
                        </div>
                    </motion.div>
                </motion.div>

                <div className="mt-12">
                    <h2 className="text-2xl font-bold text-slate-800 mb-6">Quick Actions</h2>
                    <div className="flex gap-4">
                        <a href="/admin/add-quiz" className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-6 rounded-xl shadow-md transition-colors">
                            Create New Quiz
                        </a>
                        <a href="/admin/manage-quizzes" className="bg-white hover:bg-slate-50 text-slate-700 font-bold py-3 px-6 rounded-xl border border-slate-200 shadow-sm transition-colors">
                            Manage Existing Quizzes
                        </a>
                    </div>
                </div>
            </main>
        </div>
    );
};

export default AdminHome;
