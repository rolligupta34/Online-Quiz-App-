import { Link, useNavigate } from 'react-router-dom';
import { FiLogOut, FiLayout, FiUsers, FiPlus, FiList, FiSettings } from 'react-icons/fi';
import useAuthStore from '../store/useAuthStore';
import { motion } from 'framer-motion';

const AdminNavbar = () => {
    const { logout, user } = useAuthStore();
    const navigate = useNavigate();

    const handleLogout = () => {
        logout();
        navigate('/login');
    };

    return (
        <nav className="bg-slate-900 border-b border-white/10 sticky top-0 z-50 shadow-2xl">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex items-center justify-between h-16">
                    <div className="flex items-center gap-8">
                        <Link to="/dashboard" className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-500 tracking-tighter hover:opacity-80 transition-opacity">
                            QuizMaster Admin
                        </Link>
                        <div className="hidden md:flex gap-6">
                            <Link to="/dashboard" className="text-slate-300 hover:text-white font-medium text-sm transition-colors uppercase tracking-wide">Dashboard</Link>
                            <Link to="/admin/manage-quizzes" className="text-slate-300 hover:text-white font-medium text-sm transition-colors uppercase tracking-wide">Manage Quizzes</Link>
                            <Link to="/admin/add-quiz" className="text-slate-300 hover:text-white font-medium text-sm transition-colors uppercase tracking-wide">Add Quiz</Link>
                            <Link to="/admin/manage-users" className="text-slate-300 hover:text-white font-medium text-sm transition-colors uppercase tracking-wide">Users</Link>
                        </div>
                    </div>
                    <div className="flex items-center gap-4">
                        <span className="text-slate-400 font-medium text-sm hidden sm:block">Admin: {user?.name}</span>
                        <motion.button 
                            whileHover={{ scale: 1.05 }}
                            whileTap={{ scale: 0.95 }}
                            onClick={handleLogout}
                            className="text-pink-400 hover:text-pink-300 transition-colors p-2 rounded-lg bg-pink-500/10 hover:bg-pink-500/20 flex items-center gap-2"
                        >
                            <FiSettings className="sm:hidden" />
                            <span className="hidden sm:block font-bold uppercase tracking-wider text-sm">Logout</span>
                        </motion.button>
                    </div>
                </div>
            </div>
        </nav>
    );
};

export default AdminNavbar;
