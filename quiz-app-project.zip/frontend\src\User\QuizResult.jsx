import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import api from '../services/api';
import UserNavbar from './UserNavbar';
import { motion } from 'framer-motion';
import { FiHome, FiCheckCircle } from 'react-icons/fi';

const QuizResult = () => {
    // We could fetch the specific result, or just show the latest one from the dashboard list.
    // For simplicity, we just route them back to the dashboard, 
    // or we can fetch a specific result if we had an endpoint for it.
    // Wait, the project report asked for a QuizResult.jsx.
    // Let's create a generic view or maybe just redirect them to dashboard.
    // Actually, in QuizAttempt.jsx, we redirect to dashboard.
    // We can change that to redirect to /user/result/:id if we return the result ID.
    return (
        <div className="min-h-screen bg-slate-50 font-sans flex flex-col">
            <UserNavbar />
            <main className="flex-grow flex items-center justify-center p-4">
                <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="bg-white p-12 rounded-3xl shadow-xl border border-slate-200 text-center max-w-lg w-full">
                    <div className="mx-auto w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center mb-6">
                        <FiCheckCircle className="text-5xl text-emerald-500" />
                    </div>
                    <h2 className="text-3xl font-black text-slate-900 mb-4">Simulation Complete!</h2>
                    <p className="text-slate-600 mb-8">Your results have been recorded and saved to your profile.</p>
                    <Link to="/user/dashboard" className="inline-flex items-center gap-2 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-bold py-4 px-8 rounded-xl shadow-md transition-all uppercase tracking-widest">
                        <FiHome /> Return to Dashboard
                    </Link>
                </motion.div>
            </main>
        </div>
    );
};

export default QuizResult;
