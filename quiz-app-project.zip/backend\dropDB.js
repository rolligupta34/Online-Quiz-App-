const mongoose = require('mongoose');
const dotenv = require('dotenv');

dotenv.config();

const clearDB = async () => {
    try {
        await mongoose.connect(process.env.MONGODB_URI);
        console.log('MongoDB Connected');
        await mongoose.connection.db.dropDatabase();
        console.log('Database dropped');
        process.exit();
    } catch (error) {
        console.error(error);
        process.exit(1);
    }
};

clearDB();
