const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/authMiddleware');
const {
    getPublishedQuizzes, getQuizById,
    submitQuizResult, getMyResults
} = require('../controllers/userController');

// Quizzes
router.get('/quizzes', protect, getPublishedQuizzes);
router.get('/quizzes/:id', protect, getQuizById);

// Results
router.post('/results', protect, submitQuizResult);
router.get('/results', protect, getMyResults);

module.exports = router;
