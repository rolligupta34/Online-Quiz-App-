const express = require('express');
const router = express.Router();
const { protect, admin } = require('../middleware/authMiddleware');
const {
    getMetrics,
    createQuiz, getAllQuizzes, updateQuiz, deleteQuiz,
    getAllStudents, deleteStudent, getQuizAnalytics
} = require('../controllers/adminController');

// Dashboard Metrics
router.get('/metrics', protect, admin, getMetrics);

// Quizzes
router.route('/quizzes')
    .post(protect, admin, createQuiz)
    .get(protect, admin, getAllQuizzes);

router.route('/quizzes/:id')
    .put(protect, admin, updateQuiz)
    .delete(protect, admin, deleteQuiz);

router.get('/quizzes/:id/analytics', protect, admin, getQuizAnalytics);

// Users
router.route('/students')
    .get(protect, admin, getAllStudents);

router.route('/students/:id')
    .delete(protect, admin, deleteStudent);

module.exports = router;
