import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';
import toast from 'react-hot-toast';
import AdminNavbar from './AdminNavbar';
import { motion } from 'framer-motion';

const AddQuiz = () => {
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [category, setCategory] = useState('General');
    const [timeLimit, setTimeLimit] = useState(30);
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const { data } = await api.post('/admin/quizzes', { title, description, category, timeLimit });
            toast.success('Quiz created! Now add questions.');
            navigate(`/admin/add-question/${data._id}`);
        } catch (error) {
            toast.error(error.response?.data?.message || 'Failed to create quiz');
        }
    };

    return (
        <div className="min-h-screen bg-slate-50 font-sans">
            <AdminNavbar />
            <main className="max-w-3xl mx-auto px-4 py-12">
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-white p-8 rounded-3xl shadow-sm border border-slate-200">
                    <h2 className="text-3xl font-black text-slate-900 mb-6">Create New Quiz</h2>
                    <form onSubmit={handleSubmit} className="space-y-6">
                        <div>
                            <label className="block text-sm font-bold text-slate-700 uppercase tracking-wider mb-2">Quiz Title</label>
                            <input type="text" required value={title} onChange={e => setTitle(e.target.value)}
                                className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 bg-slate-50 text-slate-900 font-medium" />
                        </div>
                        <div>
                            <label className="block text-sm font-bold text-slate-700 uppercase tracking-wider mb-2">Description</label>
                            <textarea required value={description} onChange={e => setDescription(e.target.value)} rows="3"
                                className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 bg-slate-50 text-slate-900 font-medium" />
                        </div>
                        <div className="grid grid-cols-2 gap-6">
                            <div>
                                <label className="block text-sm font-bold text-slate-700 uppercase tracking-wider mb-2">Category</label>
                                <select value={category} onChange={e => setCategory(e.target.value)}
                                    className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 bg-slate-50 text-slate-900 font-medium">
                                    <option value="General">General</option>
                                    <option value="Science">Science</option>
                                    <option value="Math">Math</option>
                                    <option value="History">History</option>
                                    <option value="Programming">Programming</option>
                                </select>
                            </div>
                            <div>
                                <label className="block text-sm font-bold text-slate-700 uppercase tracking-wider mb-2">Time Limit (Minutes)</label>
                                <input type="number" min="1" required value={timeLimit} onChange={e => setTimeLimit(e.target.value)}
                                    className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 bg-slate-50 text-slate-900 font-medium" />
                            </div>
                        </div>
                        <button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-4 rounded-xl shadow-md transition-colors uppercase tracking-widest">
                            Proceed to Add Questions
                        </button>
                    </form>
                </motion.div>
            </main>
        </div>
    );
};

export default AddQuiz;
