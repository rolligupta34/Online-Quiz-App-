import { Link, useNavigate } from 'react-router-dom';
import useAuthStore from '../store/useAuthStore';
import { motion } from 'framer-motion';
import { FiLogOut } from 'react-icons/fi';

const UserNavbar = () => {
    const { logout, user } = useAuthStore();
    const navigate = useNavigate();

    const handleLogout = () => {
        logout();
        navigate('/login');
    };

    return (
        <nav className="bg-white border-b border-slate-200 sticky top-0 z-50 shadow-sm">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex items-center justify-between h-16">
                    <div className="flex items-center gap-8">
                        <Link to="/dashboard" className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-500 to-teal-500 tracking-tighter hover:opacity-80 transition-opacity">
                            QuizMaster
                        </Link>
                        <div className="hidden md:flex gap-6">
                            <Link to="/dashboard" className="text-slate-600 hover:text-emerald-600 font-medium text-sm transition-colors uppercase tracking-wide">Dashboard</Link>
                            <Link to="/user/quizzes" className="text-slate-600 hover:text-emerald-600 font-medium text-sm transition-colors uppercase tracking-wide">Browse Quizzes</Link>
                        </div>
                    </div>
                    <div className="flex items-center gap-4">
                        <span className="text-slate-500 font-medium text-sm hidden sm:block">Student: {user?.name}</span>
                        <motion.button 
                            whileHover={{ scale: 1.05 }}
                            whileTap={{ scale: 0.95 }}
                            onClick={handleLogout}
                            className="text-slate-600 hover:text-red-500 transition-colors p-2 rounded-lg flex items-center gap-2"
                        >
                            <FiLogOut className="sm:hidden" />
                            <span className="hidden sm:block font-bold uppercase tracking-wider text-sm text-red-500">Logout</span>
                        </motion.button>
                    </div>
                </div>
            </div>
        </nav>
    );
};

export default UserNavbar;
