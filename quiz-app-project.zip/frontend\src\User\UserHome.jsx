import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import api from '../services/api';
import toast from 'react-hot-toast';
import UserNavbar from './UserNavbar';
import { motion } from 'framer-motion';
import { FiAward, FiBook } from 'react-icons/fi';

const UserHome = () => {
    const [myResults, setMyResults] = useState([]);

    useEffect(() => {
        const fetchResults = async () => {
            try {
                const { data } = await api.get('/user/results');
                setMyResults(data);
            } catch (error) {
                console.error("Failed to fetch results");
            }
        };
        fetchResults();
    }, []);

    const averageScore = myResults.length > 0 
        ? myResults.reduce((acc, curr) => acc + (curr.score / curr.totalQuestions), 0) / myResults.length * 100 
        : 0;

    return (
        <div className="min-h-screen bg-slate-50 font-sans">
            <UserNavbar />
            <main className="max-w-7xl mx-auto px-4 py-12">
                <h1 className="text-4xl font-black text-slate-900 mb-8 tracking-tight">Student Dashboard</h1>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
                    <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 flex items-center gap-6">
                        <div className="p-4 bg-emerald-100 text-emerald-600 rounded-2xl">
                            <FiBook className="text-3xl" />
                        </div>
                        <div>
                            <p className="text-sm font-bold text-slate-500 uppercase tracking-wider">Quizzes Completed</p>
                            <h3 className="text-3xl font-black text-slate-900">{myResults.length}</h3>
                        </div>
                    </div>

                    <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 flex items-center gap-6">
                        <div className="p-4 bg-teal-100 text-teal-600 rounded-2xl">
                            <FiAward className="text-3xl" />
                        </div>
                        <div>
                            <p className="text-sm font-bold text-slate-500 uppercase tracking-wider">Average Performance</p>
                            <h3 className="text-3xl font-black text-slate-900">{averageScore.toFixed(1)}%</h3>
                        </div>
                    </div>
                </div>

                <div className="mb-12">
                    <Link to="/user/quizzes" className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-black py-4 px-8 rounded-2xl shadow-lg transition-all uppercase tracking-widest inline-block">
                        Browse Available Quizzes
                    </Link>
                </div>

                <h2 className="text-2xl font-bold text-slate-800 mb-6">Recent Results</h2>
                <div className="bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden">
                    <table className="w-full text-left border-collapse">
                        <thead>
                            <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase tracking-wider text-xs font-bold">
                                <th className="p-4">Quiz Title</th>
                                <th className="p-4">Score</th>
                                <th className="p-4">Percentage</th>
                                <th className="p-4">Date Taken</th>
                            </tr>
                        </thead>
                        <tbody>
                            {myResults.map((result, idx) => {
                                const percentage = (result.score / result.totalQuestions) * 100;
                                return (
                                    <motion.tr initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: idx * 0.05 }} key={result._id} className="border-b border-slate-100 hover:bg-slate-50">
                                        <td className="p-4 font-bold text-slate-800">{result.quiz?.title || 'Deleted Quiz'}</td>
                                        <td className="p-4 font-bold text-slate-700">{result.score} / {result.totalQuestions}</td>
                                        <td className="p-4">
                                            <span className={`px-3 py-1 rounded-full text-xs font-bold ${percentage >= 70 ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'}`}>
                                                {percentage.toFixed(0)}%
                                            </span>
                                        </td>
                                        <td className="p-4 text-slate-500 text-sm">{new Date(result.createdAt).toLocaleDateString()}</td>
                                    </motion.tr>
                                );
                            })}
                        </tbody>
                    </table>
                    {myResults.length === 0 && (
                        <div className="p-8 text-center text-slate-500">You haven't taken any quizzes yet.</div>
                    )}
                </div>
            </main>
        </div>
    );
};

export default UserHome;
