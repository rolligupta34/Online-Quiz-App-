import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../services/api';
import toast from 'react-hot-toast';
import AdminNavbar from './AdminNavbar';
import { motion } from 'framer-motion';
import { FiPlus, FiSave } from 'react-icons/fi';

const AddQuestion = () => {
    const { quizId } = useParams();
    const navigate = useNavigate();
    const [quiz, setQuiz] = useState(null);
    const [questions, setQuestions] = useState([]);
    const [currentQuestion, setCurrentQuestion] = useState({ questionText: '', options: ['', '', '', ''], correctAnswer: '' });

    useEffect(() => {
        const fetchQuiz = async () => {
            try {
                // Since this is an admin route but we only have /admin/quizzes
                // We actually didn't explicitly make a getQuizById in admin, 
                // but we can use the getAllQuizzes and filter, or just update the backend later.
                // Wait, let's fetch all and find it for now, or just trust the state update.
                // It's better to fetch it if we want to show the title.
                const { data } = await api.get('/admin/quizzes');
                const targetQuiz = data.find(q => q._id === quizId);
                if(targetQuiz) {
                    setQuiz(targetQuiz);
                    setQuestions(targetQuiz.questions || []);
                }
            } catch (error) {
                toast.error("Failed to load quiz");
            }
        };
        fetchQuiz();
    }, [quizId]);

    const handleAddQuestion = () => {
        if (!currentQuestion.questionText) return toast.error("Enter question text");
        if (currentQuestion.options.some(o => !o)) return toast.error("Fill all options");
        if (!currentQuestion.correctAnswer) return toast.error("Select correct answer");

        setQuestions([...questions, currentQuestion]);
        setCurrentQuestion({ questionText: '', options: ['', '', '', ''], correctAnswer: '' });
        toast.success("Question added to list");
    };

    const handleSaveQuiz = async () => {
        try {
            await api.put(`/admin/quizzes/${quizId}`, { questions });
            toast.success("Questions saved successfully!");
            navigate('/admin/manage-quizzes');
        } catch (error) {
            toast.error("Failed to save questions");
        }
    };

    const updateOption = (index, value) => {
        const newOptions = [...currentQuestion.options];
        newOptions[index] = value;
        setCurrentQuestion({ ...currentQuestion, options: newOptions });
    };

    return (
        <div className="min-h-screen bg-slate-50 font-sans">
            <AdminNavbar />
            <main className="max-w-4xl mx-auto px-4 py-12">
                <div className="flex justify-between items-center mb-8">
                    <div>
                        <h2 className="text-3xl font-black text-slate-900">Add Questions</h2>
                        <p className="text-slate-500">Quiz: {quiz?.title}</p>
                    </div>
                    <button onClick={handleSaveQuiz} className="bg-emerald-500 hover:bg-emerald-600 text-white font-bold py-3 px-6 rounded-xl flex items-center gap-2 transition-colors">
                        <FiSave /> Save All & Finish
                    </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200">
                        <h3 className="text-xl font-bold mb-4 border-b pb-2">New Question</h3>
                        <div className="space-y-4">
                            <div>
                                <label className="block text-sm font-bold text-slate-700 mb-2">Question Text</label>
                                <textarea value={currentQuestion.questionText} onChange={e => setCurrentQuestion({...currentQuestion, questionText: e.target.value})} rows="3"
                                    className="w-full px-4 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 bg-slate-50" />
                            </div>
                            
                            {currentQuestion.options.map((opt, i) => (
                                <div key={i} className="flex items-center gap-3">
                                    <input type="radio" name="correct" checked={currentQuestion.correctAnswer === opt && opt !== ''}
                                        onChange={() => setCurrentQuestion({...currentQuestion, correctAnswer: opt})}
                                        className="w-5 h-5 text-indigo-600" title="Mark as correct" />
                                    <input type="text" placeholder={`Option ${i+1}`} value={opt} onChange={e => updateOption(i, e.target.value)}
                                        className="w-full px-4 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 bg-slate-50" />
                                </div>
                            ))}
                            
                            <button onClick={handleAddQuestion} className="w-full bg-indigo-100 hover:bg-indigo-200 text-indigo-700 font-bold py-3 rounded-xl flex items-center justify-center gap-2 transition-colors">
                                <FiPlus /> Add to Quiz
                            </button>
                        </div>
                    </motion.div>

                    <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-4">
                        <h3 className="text-xl font-bold border-b pb-2">Current Questions ({questions.length})</h3>
                        {questions.map((q, i) => (
                            <div key={i} className="bg-white p-4 rounded-2xl shadow-sm border border-slate-200">
                                <p className="font-bold text-slate-800 mb-2">Q{i+1}: {q.questionText}</p>
                                <ul className="text-sm text-slate-600 space-y-1 ml-4">
                                    {q.options.map((o, oi) => (
                                        <li key={oi} className={o === q.correctAnswer ? 'text-emerald-600 font-bold' : ''}>• {o}</li>
                                    ))}
                                </ul>
                            </div>
                        ))}
                    </motion.div>
                </div>
            </main>
        </div>
    );
};

export default AddQuestion;
