const fs = require('fs');
const path = require('path');

const dir = path.join(__dirname, '../src/pages');
const files = ['Dashboard.jsx', 'TakeQuiz.jsx', 'Login.jsx', 'Register.jsx'];

const replacements = [
  [/from-gray-700 to-gray-800 border border-white\/20/g, 'from-indigo-100 to-pink-100 border border-slate-200'],
  [/border-white\/20/g, 'border-slate-200'],
  [/border-white\/10/g, 'border-slate-200'],
  [/border border-slate-100/g, 'border border-slate-200'],
  [/shadow-\[0_0_40px_rgba\(99,102,241,0.15\)\]/g, 'shadow-2xl shadow-indigo-200/50'],
  [/shadow-inner/g, 'shadow-sm'],
  [/from-indigo-400 to-pink-400/g, 'from-indigo-600 to-pink-600'],
  [/text-indigo-400/g, 'text-indigo-600'],
  [/text-pink-400/g, 'text-pink-600'],
  [/text-slate-900 text-xl/g, 'text-white text-xl'],
  [/hover:text-slate-900/g, 'hover:text-white'], 
  [/bg-white\/5 /g, 'bg-slate-50 '],
  [/bg-white\/10/g, 'bg-slate-100'],
  [/border-slate-100/g, 'border-slate-200'],
  [/from-white/g, 'from-slate-800'],
  [/to-slate-500/g, 'to-slate-600'],
  [/bg-black\/50/g, 'bg-white/90'],
  [/bg-black\/40/g, 'bg-white/80'],
  [/bg-black\/30/g, 'bg-white/70'],
  [/bg-black\/20/g, 'bg-white/60'],
  [/text-red-400/g, 'text-red-500'],
  [/text-gray-400/g, 'text-slate-500'],
  [/text-gray-300/g, 'text-slate-600'],
  [/text-gray-200/g, 'text-slate-800'],
  [/text-white/g, 'text-slate-900'] // Careful with this one
];

files.forEach(file => {
  const filePath = path.join(dir, file);
  if (!fs.existsSync(filePath)) return;
  
  let content = fs.readFileSync(filePath, 'utf8');
  replacements.forEach(([regex, to]) => {
    content = content.replace(regex, to);
  });
  
  // Specific fixes
  content = content.replace(/className="text-slate-900 text-xl"/g, 'className="text-white text-xl"');
  content = content.replace(/text-slate-900 px-6 py-4/g, 'text-white px-6 py-4'); // create quiz button 
  content = content.replace(/text-slate-900 px-4 py-3.5/g, 'text-white px-4 py-3.5'); // execute button
  content = content.replace(/text-slate-900 text-3xl/g, 'text-white text-3xl'); // login icon
  content = content.replace(/text-slate-900 bg-gradient/g, 'text-white bg-gradient'); // buttons
  content = content.replace(/text-lg font-bold text-slate-900/g, 'text-lg font-bold text-white'); // form submit buttons
  
  fs.writeFileSync(filePath, content, 'utf8');
  console.log(`Updated ${file}`);
});
