import { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import api from '../services/api';
import toast from 'react-hot-toast';
import UserNavbar from './UserNavbar';
import { motion } from 'framer-motion';
import { FiClock, FiFileText, FiArrowLeft, FiPlay } from 'react-icons/fi';

const QuizDetail = () => {
    const { id } = useParams();
    const [quiz, setQuiz] = useState(null);
    const navigate = useNavigate();

    useEffect(() => {
        const fetchQuiz = async () => {
            try {
                const { data } = await api.get(`/user/quizzes/${id}`);
                setQuiz(data);
            } catch (error) {
                toast.error("Quiz not found or not available");
                navigate('/user/quizzes');
            }
        };
        fetchQuiz();
    }, [id, navigate]);

    if (!quiz) return <div className="min-h-screen bg-slate-50 font-sans flex items-center justify-center"><div className="animate-pulse text-2xl font-bold text-slate-400">Loading Module...</div></div>;

    return (
        <div className="min-h-screen bg-slate-50 font-sans">
            <UserNavbar />
            <main className="max-w-3xl mx-auto px-4 py-12">
                <Link to="/user/quizzes" className="inline-flex items-center gap-2 text-slate-500 hover:text-slate-900 mb-8 font-bold transition-colors">
                    <FiArrowLeft /> Back to Modules
                </Link>

                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-white p-8 rounded-3xl shadow-sm border border-slate-200">
                    <div className="inline-block bg-emerald-100 text-emerald-700 px-4 py-1.5 rounded-full text-sm font-bold uppercase tracking-wider mb-6">
                        {quiz.category}
                    </div>
                    
                    <h1 className="text-4xl font-black text-slate-900 mb-4">{quiz.title}</h1>
                    <p className="text-lg text-slate-600 mb-8 leading-relaxed">{quiz.description}</p>
                    
                    <div className="grid grid-cols-2 gap-4 mb-8">
                        <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 flex flex-col items-center justify-center text-center">
                            <FiClock className="text-3xl text-emerald-500 mb-2" />
                            <p className="font-bold text-slate-800">{quiz.timeLimit} Minutes</p>
                            <p className="text-xs text-slate-500 uppercase tracking-wider">Time Limit</p>
                        </div>
                        <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 flex flex-col items-center justify-center text-center">
                            <FiFileText className="text-3xl text-teal-500 mb-2" />
                            <p className="font-bold text-slate-800">{quiz.questions.length} Questions</p>
                            <p className="text-xs text-slate-500 uppercase tracking-wider">Total length</p>
                        </div>
                    </div>

                    <div className="bg-amber-50 border border-amber-200 p-6 rounded-2xl mb-8">
                        <h4 className="font-bold text-amber-800 mb-2">Important Instructions</h4>
                        <ul className="list-disc list-inside text-amber-700 space-y-1 text-sm">
                            <li>Once you start, the timer cannot be paused.</li>
                            <li>If time runs out, the quiz will auto-submit.</li>
                            <li>Do not refresh the page during the quiz.</li>
                        </ul>
                    </div>

                    <Link to={`/user/attempt/${quiz._id}`} className="flex items-center justify-center gap-2 w-full bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-black py-4 rounded-xl shadow-lg transition-all uppercase tracking-widest text-lg">
                        <FiPlay /> Start Simulation
                    </Link>
                </motion.div>
            </main>
        </div>
    );
};

export default QuizDetail;
