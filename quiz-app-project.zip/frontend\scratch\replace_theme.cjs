const fs = require('fs');
const path = require('path');

const dir = path.join(__dirname, '../src/pages');
const files = ['Dashboard.jsx', 'TakeQuiz.jsx', 'Login.jsx', 'Register.jsx'];

const replacements = {
  'bg-black/50': 'bg-white/90',
  'bg-black/40': 'bg-white/80',
  'bg-black/30': 'bg-white/70',
  'bg-black/20': 'bg-white/60',
  'bg-white/5': 'bg-white/60',
  'bg-white/10': 'bg-white/80',
  'bg-white/\\[0.02\\]': 'bg-white/50',
  'border-white/10': 'border-slate-200',
  'border-white/5': 'border-slate-100',
  'text-gray-200': 'text-slate-800',
  'text-gray-300': 'text-slate-700',
  'text-gray-400': 'text-slate-600',
  'text-gray-500': 'text-slate-500',
  'text-white': 'text-slate-900',
  'from-white': 'from-slate-800',
  'to-gray-400': 'to-slate-500',
  'bg-black': 'bg-white'
};

files.forEach(file => {
  const filePath = path.join(dir, file);
  if (!fs.existsSync(filePath)) return;
  
  let content = fs.readFileSync(filePath, 'utf8');
  Object.entries(replacements).forEach(([from, to]) => {
    // Only replacing the class strings
    // the backslash is already in the object key for from, we just do a simple split join if regex is tricky, but let's just do split join
    content = content.split(from).join(to);
  });
  
  fs.writeFileSync(filePath, content, 'utf8');
  console.log(`Updated ${file}`);
});
