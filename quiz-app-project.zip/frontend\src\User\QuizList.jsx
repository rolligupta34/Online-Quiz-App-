import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import api from '../services/api';
import toast from 'react-hot-toast';
import UserNavbar from './UserNavbar';
import { motion } from 'framer-motion';
import { FiSearch, FiClock, FiFileText } from 'react-icons/fi';

const QuizList = () => {
    const [quizzes, setQuizzes] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedCategory, setSelectedCategory] = useState('All');

    useEffect(() => {
        const fetchQuizzes = async () => {
            try {
                const { data } = await api.get('/user/quizzes');
                setQuizzes(data);
            } catch (error) {
                toast.error("Failed to load quizzes");
            }
        };
        fetchQuizzes();
    }, []);

    const categories = ['All', ...new Set(quizzes.map(q => q.category))];

    const filteredQuizzes = quizzes.filter(quiz => {
        const matchesSearch = quiz.title.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesCategory = selectedCategory === 'All' || quiz.category === selectedCategory;
        return matchesSearch && matchesCategory;
    });

    return (
        <div className="min-h-screen bg-slate-50 font-sans">
            <UserNavbar />
            <main className="max-w-7xl mx-auto px-4 py-12">
                <div className="flex flex-col md:flex-row justify-between items-center mb-12 gap-6">
                    <h1 className="text-4xl font-black text-slate-900 tracking-tight">Available Modules</h1>
                    <div className="flex gap-4 w-full md:w-auto">
                        <div className="relative flex-1 md:w-64">
                            <FiSearch className="absolute left-4 top-3.5 text-slate-400" />
                            <input type="text" placeholder="Search modules..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)}
                                className="w-full pl-10 pr-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none" />
                        </div>
                        <select value={selectedCategory} onChange={e => setSelectedCategory(e.target.value)}
                            className="px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none bg-white">
                            {categories.map(c => <option key={c} value={c}>{c}</option>)}
                        </select>
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {filteredQuizzes.map((quiz, idx) => (
                        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: idx * 0.05 }} key={quiz._id} 
                            className="bg-white p-6 rounded-3xl shadow-sm hover:shadow-xl transition-shadow border border-slate-200 flex flex-col h-full relative overflow-hidden">
                            <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-emerald-400 to-teal-500"></div>
                            
                            <div className="flex justify-between items-start mb-4 mt-2">
                                <span className="bg-emerald-100 text-emerald-700 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider">{quiz.category}</span>
                            </div>
                            
                            <h3 className="text-2xl font-black text-slate-900 mb-2">{quiz.title}</h3>
                            <p className="text-slate-600 mb-6 flex-grow">{quiz.description}</p>
                            
                            <div className="flex items-center justify-between text-sm text-slate-500 font-bold mb-6">
                                <span className="flex items-center gap-2"><FiClock /> {quiz.timeLimit} mins</span>
                                <span className="flex items-center gap-2"><FiFileText /> {quiz.questions.length} questions</span>
                            </div>
                            
                            <Link to={`/user/quiz/${quiz._id}`} className="block w-full text-center bg-slate-900 hover:bg-slate-800 text-white font-bold py-3 rounded-xl transition-colors uppercase tracking-widest text-sm">
                                View Details
                            </Link>
                        </motion.div>
                    ))}
                </div>
                {filteredQuizzes.length === 0 && (
                    <div className="text-center py-20">
                        <p className="text-2xl font-bold text-slate-400">No modules found matching your criteria.</p>
                    </div>
                )}
            </main>
        </div>
    );
};

export default QuizList;
