import { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../services/api';
import toast from 'react-hot-toast';
import { motion, AnimatePresence } from 'framer-motion';
import { FiClock, FiAlertCircle } from 'react-icons/fi';

const QuizAttempt = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const [quiz, setQuiz] = useState(null);
    const [currentQuestion, setCurrentQuestion] = useState(0);
    const [answers, setAnswers] = useState({});
    const [timeLeft, setTimeLeft] = useState(null);
    const [isSubmitting, setIsSubmitting] = useState(false);

    useEffect(() => {
        const fetchQuiz = async () => {
            try {
                const { data } = await api.get(`/user/quizzes/${id}`);
                setQuiz(data);
                setTimeLeft(data.timeLimit * 60); // convert to seconds
            } catch (error) {
                toast.error("Quiz unavailable");
                navigate('/user/quizzes');
            }
        };
        fetchQuiz();
    }, [id, navigate]);

    const handleSubmit = useCallback(async () => {
        if (isSubmitting || !quiz) return;
        setIsSubmitting(true);
        
        let score = 0;
        quiz.questions.forEach((q, index) => {
            if (answers[index] === q.correctAnswer) score += 1;
        });

        try {
            await api.post('/user/results', {
                quizId: quiz._id,
                score,
                totalQuestions: quiz.questions.length
            });
            navigate('/user/result');
            toast.success("Simulation Complete!");
        } catch (error) {
            toast.error("Failed to submit results");
            setIsSubmitting(false);
        }
    }, [answers, isSubmitting, navigate, quiz]);

    useEffect(() => {
        if (timeLeft === null) return;
        if (timeLeft <= 0) {
            toast.error("Time's up! Auto-submitting...");
            handleSubmit();
            return;
        }
        const timerId = setInterval(() => {
            setTimeLeft(prev => prev - 1);
        }, 1000);
        return () => clearInterval(timerId);
    }, [timeLeft, handleSubmit]);

    const handleSelectOption = (option) => {
        setAnswers({ ...answers, [currentQuestion]: option });
    };

    if (!quiz) return <div className="min-h-screen bg-slate-900 flex items-center justify-center text-emerald-400 font-bold text-2xl animate-pulse">Initializing Simulation...</div>;

    const formatTime = (seconds) => {
        const m = Math.floor(seconds / 60);
        const s = seconds % 60;
        return `${m}:${s < 10 ? '0' : ''}${s}`;
    };

    const isLastQuestion = currentQuestion === quiz.questions.length - 1;
    const isWarningTime = timeLeft < 60;

    return (
        <div className="min-h-screen bg-slate-900 font-sans text-slate-200">
            {/* Header / HUD */}
            <header className="bg-slate-800 border-b border-slate-700 sticky top-0 z-50 shadow-md">
                <div className="max-w-4xl mx-auto px-4 h-16 flex items-center justify-between">
                    <h2 className="font-bold truncate max-w-[200px] sm:max-w-md">{quiz.title}</h2>
                    <div className={`flex items-center gap-2 font-black text-xl px-4 py-1.5 rounded-lg ${isWarningTime ? 'bg-red-500/20 text-red-400 animate-pulse' : 'bg-slate-700 text-emerald-400'}`}>
                        {isWarningTime && <FiAlertCircle />}
                        <FiClock /> {formatTime(timeLeft)}
                    </div>
                </div>
            </header>

            <main className="max-w-3xl mx-auto px-4 py-8">
                {/* Progress Bar */}
                <div className="mb-8">
                    <div className="flex justify-between text-sm font-bold text-slate-400 mb-2">
                        <span>Progress</span>
                        <span>{Object.keys(answers).length} / {quiz.questions.length} Answered</span>
                    </div>
                    <div className="w-full bg-slate-800 rounded-full h-2.5">
                        <div className="bg-gradient-to-r from-emerald-500 to-teal-400 h-2.5 rounded-full transition-all duration-300" style={{ width: `${(Object.keys(answers).length / quiz.questions.length) * 100}%` }}></div>
                    </div>
                </div>

                {/* Question Area */}
                <AnimatePresence mode="wait">
                    <motion.div 
                        key={currentQuestion}
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -20 }}
                        transition={{ duration: 0.2 }}
                        className="bg-slate-800 p-6 md:p-8 rounded-3xl shadow-xl border border-slate-700"
                    >
                        <span className="text-emerald-500 font-bold uppercase tracking-wider text-sm mb-4 block">Question {currentQuestion + 1} of {quiz.questions.length}</span>
                        <h3 className="text-2xl font-bold text-white mb-8">{quiz.questions[currentQuestion].questionText}</h3>
                        
                        <div className="space-y-4">
                            {quiz.questions[currentQuestion].options.map((option, idx) => {
                                const isSelected = answers[currentQuestion] === option;
                                return (
                                    <button 
                                        key={idx}
                                        onClick={() => handleSelectOption(option)}
                                        className={`w-full text-left p-4 rounded-xl border-2 transition-all font-medium ${isSelected ? 'border-emerald-500 bg-emerald-500/10 text-emerald-300' : 'border-slate-600 bg-slate-700 hover:border-slate-500 text-slate-300 hover:bg-slate-600'}`}
                                    >
                                        <div className="flex items-center gap-3">
                                            <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 ${isSelected ? 'border-emerald-500' : 'border-slate-500'}`}>
                                                {isSelected && <div className="w-2.5 h-2.5 rounded-full bg-emerald-500"></div>}
                                            </div>
                                            <span>{option}</span>
                                        </div>
                                    </button>
                                );
                            })}
                        </div>
                    </motion.div>
                </AnimatePresence>

                {/* Navigation */}
                <div className="flex justify-between mt-8">
                    <button 
                        onClick={() => setCurrentQuestion(prev => Math.max(0, prev - 1))}
                        disabled={currentQuestion === 0}
                        className="px-6 py-3 rounded-xl font-bold text-slate-400 hover:text-white hover:bg-slate-800 disabled:opacity-30 transition-colors"
                    >
                        Previous
                    </button>
                    
                    {isLastQuestion ? (
                        <button 
                            onClick={handleSubmit}
                            disabled={isSubmitting}
                            className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white px-8 py-3 rounded-xl font-black shadow-lg shadow-emerald-500/20 disabled:opacity-50 transition-all"
                        >
                            {isSubmitting ? 'Submitting...' : 'Submit Final Answers'}
                        </button>
                    ) : (
                        <button 
                            onClick={() => setCurrentQuestion(prev => Math.min(quiz.questions.length - 1, prev + 1))}
                            className="bg-slate-800 hover:bg-slate-700 text-white px-8 py-3 rounded-xl font-bold transition-colors"
                        >
                            Next Question
                        </button>
                    )}
                </div>
            </main>
        </div>
    );
};

export default QuizAttempt;
