import { useState, useEffect } from 'react';
import api from '../services/api';
import toast from 'react-hot-toast';
import AdminNavbar from './AdminNavbar';
import { motion } from 'framer-motion';
import { FiTrash2 } from 'react-icons/fi';

const ManageUsers = () => {
    const [students, setStudents] = useState([]);

    const fetchStudents = async () => {
        try {
            const { data } = await api.get('/admin/students');
            setStudents(data);
        } catch (error) {
            toast.error("Failed to load students");
        }
    };

    useEffect(() => {
        fetchStudents();
    }, []);

    const deleteStudent = async (id) => {
        if (!window.confirm("Delete this student and all their results?")) return;
        try {
            await api.delete(`/admin/students/${id}`);
            toast.success("Student removed");
            fetchStudents();
        } catch (error) {
            toast.error("Failed to delete student");
        }
    };

    return (
        <div className="min-h-screen bg-slate-50 font-sans">
            <AdminNavbar />
            <main className="max-w-7xl mx-auto px-4 py-12">
                <h2 className="text-3xl font-black text-slate-900 mb-8">Manage Students</h2>

                <div className="bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden">
                    <table className="w-full text-left border-collapse">
                        <thead>
                            <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase tracking-wider text-xs font-bold">
                                <th className="p-4">Name</th>
                                <th className="p-4">Email</th>
                                <th className="p-4">Joined Date</th>
                                <th className="p-4 text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {students.map((student, idx) => (
                                <motion.tr initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: idx * 0.05 }} key={student._id} className="border-b border-slate-100 hover:bg-slate-50">
                                    <td className="p-4 font-bold text-slate-800">{student.name}</td>
                                    <td className="p-4 text-slate-600">{student.email}</td>
                                    <td className="p-4 text-slate-500 text-sm">{new Date(student.createdAt).toLocaleDateString()}</td>
                                    <td className="p-4 flex justify-end">
                                        <button onClick={() => deleteStudent(student._id)} className="text-red-500 hover:bg-red-50 p-2 rounded-lg" title="Delete">
                                            <FiTrash2 />
                                        </button>
                                    </td>
                                </motion.tr>
                            ))}
                        </tbody>
                    </table>
                    {students.length === 0 && (
                        <div className="p-8 text-center text-slate-500">No students registered yet.</div>
                    )}
                </div>
            </main>
        </div>
    );
};

export default ManageUsers;
