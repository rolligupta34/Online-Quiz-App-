const User = require('../models/User');
const Quiz = require('../models/Quiz');
const Result = require('../models/Result');
const jwt = require('jsonwebtoken');

const generateToken = (id) => {
    return jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: '30d' });
};

// --- AUTH ---
// Moved to authController.js

// --- QUIZZES ---
const getPublishedQuizzes = async (req, res) => {
    try {
        const quizzes = await Quiz.find({ isPublished: true }).populate('creator', 'name');
        res.json(quizzes);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

const getQuizById = async (req, res) => {
    try {
        const quiz = await Quiz.findOne({ _id: req.params.id, isPublished: true }).populate('creator', 'name');
        if (quiz) res.json(quiz);
        else res.status(404).json({ message: 'Quiz not found or not published' });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// --- RESULTS ---
const submitQuizResult = async (req, res) => {
    const { quizId, score, totalQuestions } = req.body;
    try {
        const result = await Result.create({
            student: req.user._id,
            quiz: quizId,
            score,
            totalQuestions
        });
        res.status(201).json(result);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
};

const getMyResults = async (req, res) => {
    try {
        const results = await Result.find({ student: req.user._id }).populate('quiz', 'title category');
        res.json(results);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

module.exports = {
    getPublishedQuizzes, getQuizById,
    submitQuizResult, getMyResults
};
