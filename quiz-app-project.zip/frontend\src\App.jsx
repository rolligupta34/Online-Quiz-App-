import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import useAuthStore from './store/useAuthStore';

// Unified Auth
import Login from './Auth/Login';
import Signup from './Auth/Signup';

// Admin Imports
import AdminHome from './Admin/AdminHome';
import AddQuiz from './Admin/AddQuiz';
import AddQuestion from './Admin/AddQuestion';
import ManageQuizzes from './Admin/ManageQuizzes';
import ManageUsers from './Admin/ManageUsers';
import QuizAnalytics from './Admin/QuizAnalytics';

// User Imports
import UserHome from './User/UserHome';
import QuizList from './User/QuizList';
import QuizDetail from './User/QuizDetail';
import QuizAttempt from './User/QuizAttempt';
import QuizResult from './User/QuizResult';

function App() {
  const { user } = useAuthStore();

  return (
    <>
      <Router>
        <Routes>
          {/* Unified Auth Routes */}
          <Route path="/login" element={!user ? <Login /> : <Navigate to="/dashboard" />} />
          <Route path="/register" element={!user ? <Signup /> : <Navigate to="/dashboard" />} />

          {/* Unified Dashboard Route */}
          <Route path="/dashboard" element={
            !user ? <Navigate to="/login" /> : 
            user.role === 'admin' ? <AdminHome /> : <UserHome />
          } />

          {/* Admin Routes */}
          <Route path="/admin/add-quiz" element={(user && user.role === 'admin') ? <AddQuiz /> : <Navigate to="/login" />} />
          <Route path="/admin/add-question/:quizId" element={(user && user.role === 'admin') ? <AddQuestion /> : <Navigate to="/login" />} />
          <Route path="/admin/manage-quizzes" element={(user && user.role === 'admin') ? <ManageQuizzes /> : <Navigate to="/login" />} />
          <Route path="/admin/manage-users" element={(user && user.role === 'admin') ? <ManageUsers /> : <Navigate to="/login" />} />
          <Route path="/admin/analytics/:quizId" element={(user && user.role === 'admin') ? <QuizAnalytics /> : <Navigate to="/login" />} />

          {/* User Routes */}
          <Route path="/user/quizzes" element={(user && user.role === 'student') ? <QuizList /> : <Navigate to="/login" />} />
          <Route path="/user/quiz/:id" element={(user && user.role === 'student') ? <QuizDetail /> : <Navigate to="/login" />} />
          <Route path="/user/attempt/:id" element={(user && user.role === 'student') ? <QuizAttempt /> : <Navigate to="/login" />} />
          <Route path="/user/result" element={(user && user.role === 'student') ? <QuizResult /> : <Navigate to="/login" />} />

          {/* Root Redirect */}
          <Route path="/" element={<Navigate to={user ? "/dashboard" : "/login"} />} />
        </Routes>
      </Router>
      <Toaster position="top-right" />
    </>
  );
}

export default App;
